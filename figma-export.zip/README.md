
  # Redesign Home Screen

  This is a code bundle for Redesign Home Screen. The original project is available at https://www.figma.com/design/ObZgj6Ylz72Jm4O8eaGzWE/Redesign-Home-Screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  