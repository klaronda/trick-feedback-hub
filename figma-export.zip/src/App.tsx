import { useState } from 'react';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import { Progress } from './components/ui/progress';
import { Badge } from './components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { 
  Home, 
  Video, 
  MessageCircle,
  User, 
  Upload, 
  Bell,
  Play,
  Clock,
  CheckCircle2,
  Send,
  Megaphone,
  PlaySquare,
  ArrowLeft,
  Trash2,
  RotateCcw,
  Search,
  Edit,
  Settings,
  Smartphone,
  Camera,
  Mic,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  X,
  Bookmark,
  Heart,
  Zap
} from 'lucide-react';
import { Input } from './components/ui/input';
import { Slider } from './components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Label } from './components/ui/label';
import { RadioGroup, RadioGroupItem } from './components/ui/radio-group';
import { Textarea } from './components/ui/textarea';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './components/ui/dialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './components/ui/tooltip';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [userPlan] = useState('pro'); // free or pro
  const [uploadsUsed] = useState(3);
  const [uploadsLimit] = useState(5);
  const [selectedVideo, setSelectedVideo] = useState<number | null>(null);
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [tipModalOpen, setTipModalOpen] = useState(false);
  const [savedTips, setSavedTips] = useState<number[]>([]);
  
  // Delete confirmation states
  const [deleteConfirmation, setDeleteConfirmation] = useState<{
    isOpen: boolean;
    type: 'tip' | 'video' | null;
    id: number | null;
    title: string;
  }>({
    isOpen: false,
    type: null,
    id: null,
    title: ''
  });
  
  // Upload modal states
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [uploadStep, setUploadStep] = useState<'search' | 'video' | 'trim'>('search');
  const [selectedTrick, setSelectedTrick] = useState('');
  const [uploadNotes, setUploadNotes] = useState('');
  const [selectedVideoFile, setSelectedVideoFile] = useState<File | null>(null);
  const [videoDuration, setVideoDuration] = useState(0);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(5);
  const [showTrickSuggestions, setShowTrickSuggestions] = useState(false);
  
  // Notifications modal state
  const [notificationsModalOpen, setNotificationsModalOpen] = useState(false);
  
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Start as true for demo
  const [authView, setAuthView] = useState<'signin' | 'signup'>('signin');
  
  // Profile editing states
  const [editProfileModalOpen, setEditProfileModalOpen] = useState(false);
  const [imageUploadModalOpen, setImageUploadModalOpen] = useState(false);
  const [selectedProfileImage, setSelectedProfileImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [cropScale, setCropScale] = useState(1);
  const [cropPosition, setCropPosition] = useState({ x: 0, y: 0 });
  
  // Account deletion states
  const [deleteAccountStep, setDeleteAccountStep] = useState<'initial' | 'confirm' | null>(null);
  
  // Subscription management states
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [cancelSubscriptionStep, setCancelSubscriptionStep] = useState<'initial' | 'confirm' | null>(null);
  
  // App permissions states
  const [permissions, setPermissions] = useState({
    pushNotifications: true,
    camera: true,
    microphone: true
  });
  const [permissionConfirmModal, setPermissionConfirmModal] = useState<{
    isOpen: boolean;
    type: 'pushNotifications' | 'camera' | 'microphone' | null;
    action: 'disable' | 'enable' | null;
  }>({
    isOpen: false,
    type: null,
    action: null
  });
  
  // Videos page search states
  const [videosSearchQuery, setVideosSearchQuery] = useState('');
  const [showVideosSearchSuggestions, setShowVideosSearchSuggestions] = useState(false);
  
  // Onboarding states
  const [isOnboarding, setIsOnboarding] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [skaterDetails, setSkaterDetails] = useState({
    firstName: 'Alex',
    lastName: 'Rodriguez',
    startedSkating: '2018',
    stance: 'regular',
    gender: 'male',
    birthMonth: '6',
    birthDay: '15',
    birthYear: '1995',
    learningGoals: 'I want to master kickflips and heelflips, and eventually learn tre flips. Also working on improving my balance and consistency with basic tricks.'
  });

  const recentUploads = [
    {
      id: 1,
      trick: 'Kickflip',
      status: 'completed',
      feedback: 'Great progress on your pop timing! Focus on keeping your shoulders aligned.',
      timestamp: '2 hours ago',
      score: 7.2
    },
    {
      id: 2,
      trick: 'Ollie',
      status: 'processing',
      feedback: 'We\'re reviewing your technique',
      timestamp: '5 minutes ago',
      score: null
    },
    {
      id: 3,
      trick: 'Heelflip',
      status: 'completed',
      feedback: 'Nice attempt! Try jumping higher and flicking with more force.',
      timestamp: 'Yesterday',
      score: 6.8
    }
  ];

  const videosByMonth = {
    'September 2024': [
      {
        id: 1,
        trick: 'Kickflip',
        status: 'completed',
        feedback: 'Great progress on your pop timing! Focus on keeping your shoulders aligned.',
        timestamp: '2 hours ago',
        score: 7.2,
        videoUrl: 'https://www.example.com/sample-video.mp4'
      },
      {
        id: 2,
        trick: 'Kickflip',
        status: 'completed',
        feedback: 'Nice attempt! Your board rotation is getting much better.',
        timestamp: 'Yesterday',
        score: 6.8,
        videoUrl: 'https://www.example.com/sample-video.mp4'
      },
      {
        id: 3,
        trick: 'Heelflip',
        status: 'processing',
        feedback: 'We\'re reviewing your technique',
        timestamp: '2 days ago',
        score: null,
        videoUrl: 'https://www.example.com/sample-video.mp4'
      }
    ],
    'August 2024': [
      {
        id: 4,
        trick: 'Ollie',
        status: 'completed',
        feedback: 'Good balance! Try to commit more to the landing.',
        timestamp: 'Aug 28',
        score: 7.0,
        videoUrl: 'https://www.example.com/sample-video.mp4'
      },
      {
        id: 5,
        trick: 'Kickflip',
        status: 'completed',
        feedback: 'Focus on flicking more with your front foot for cleaner rotation.',
        timestamp: 'Aug 25',
        score: 6.5,
        videoUrl: 'https://www.example.com/sample-video.mp4'
      }
    ]
  };

  const coachMessages = [
    {
      id: 1,
      type: 'coach',
      message: "Hey! I noticed you've been working on kickflips. What specific part are you struggling with the most?",
      timestamp: '2 hours ago'
    },
    {
      id: 2,
      type: 'user',
      message: "I can't seem to get the board to flip all the way around. It only does like 3/4 of a rotation.",
      timestamp: '2 hours ago'
    },
    {
      id: 3,
      type: 'coach',
      message: "That's a common issue! Try flicking your front foot more towards the corner of the nose, and make sure you're jumping higher. The extra height gives the board more time to complete the rotation.",
      timestamp: '2 hours ago'
    }
  ];

  const videoCoachMessages = [
    {
      id: 1,
      type: 'coach',
      message: "I've reviewed your kickflip attempt. Your pop timing is really good! The main area to focus on is keeping your shoulders more aligned with the board.",
      timestamp: '2 hours ago'
    },
    {
      id: 2,
      type: 'user',
      message: "Thanks! Should I be looking down at the board or ahead?",
      timestamp: '2 hours ago'
    },
    {
      id: 3,
      type: 'coach',
      message: "Great question! Try to keep your eyes focused on where you want to land, not down at the board. This helps with balance and commitment to the trick.",
      timestamp: '1 hour ago'
    }
  ];

  const improvementTags = [
    { id: 'pop', label: 'Pop' },
    { id: 'balance', label: 'Balance' },
    { id: 'feet', label: 'Feet' },
    { id: 'legs', label: 'Legs' },
    { id: 'shoulders', label: 'Shoulders' },
    { id: 'body', label: 'Body' },
    { id: 'comfort', label: 'Comfort' },
    { id: 'confidence', label: 'Confidence' },
    { id: 'not-sure', label: 'Not Sure' }
  ];

  const trickSuggestions = [
    'Ollie', 'Kickflip', 'Heelflip', 'Pop Shuvit', 'Frontside 180', 'Backside 180',
    'Varial Kickflip', 'Varial Heelflip', 'Tre Flip', 'Hardflip', 'Inward Heelflip',
    'Frontside Shuvit', 'Backside Shuvit', 'Kickflip Underflip', 'Heelflip Underflip',
    'Fakie Ollie', 'Nollie', 'Switch Ollie', 'Manual', 'Nose Manual', 'Casper Slide',
    'Rail Stand', 'Pogo', 'Primo', 'Darkslide', 'Fingerflip', 'Hospital Flip'
  ];

  const activityData = [
    {
      id: 1,
      type: 'video_uploaded',
      title: 'Video uploaded',
      description: 'Your Kickflip attempt is being reviewed by Coach',
      timestamp: '2 hours ago',
      icon: Upload
    },
    {
      id: 2,
      type: 'push_notification',
      title: 'Coach feedback ready',
      description: 'Your Heelflip analysis is complete with coaching tips',
      timestamp: '4 hours ago',
      icon: Bell
    },
    {
      id: 3,
      type: 'tip_saved',
      title: 'Tip saved',
      description: 'You saved "Master Your Ollie Foundation" to your collection',
      timestamp: 'Yesterday',
      icon: Bookmark
    },
    {
      id: 4,
      type: 'video_uploaded',
      title: 'Video uploaded',
      description: 'Your Ollie attempt has been uploaded successfully',
      timestamp: 'Yesterday',
      icon: Upload
    },
    {
      id: 5,
      type: 'push_notification',
      title: 'Daily tip available',
      description: 'New trick tip: "Kickflip Foot Positioning" is ready to view',
      timestamp: '2 days ago',
      icon: Bell
    },
    {
      id: 6,
      type: 'coach_message',
      title: 'Coach message',
      description: 'Coach replied to your question about landing consistency',
      timestamp: '2 days ago',
      icon: MessageCircle
    },
    {
      id: 7,
      type: 'tip_saved',
      title: 'Tip saved',
      description: 'You saved "Mental Game & Commitment" to your collection',
      timestamp: '3 days ago',
      icon: Bookmark
    },
    {
      id: 8,
      type: 'video_uploaded',
      title: 'Video uploaded',
      description: 'Your Pop Shuvit attempt is being reviewed by Coach',
      timestamp: '3 days ago',
      icon: Upload
    },
    {
      id: 9,
      type: 'push_notification',
      title: 'Weekly progress',
      description: 'You uploaded 5 videos this week! Keep up the great work',
      timestamp: '1 week ago',
      icon: Bell
    },
    {
      id: 10,
      type: 'coach_message',
      title: 'Welcome message',
      description: 'Welcome to SkateCoach! Ready to improve your skating?',
      timestamp: '2 weeks ago',
      icon: MessageCircle
    }
  ];

  const dailyTrickTips = [
    {
      id: 1,
      title: 'Master Your Ollie Foundation',
      description: 'Focus on the timing between your back foot pop and front foot slide. Practice stationary first.',
      category: 'Basics',
      details: 'The ollie is the foundation of almost every skateboard trick. Getting this right will unlock your potential for more advanced moves.',
      bullets: [
        'Position your back foot on the tail with the ball of your foot centered',
        'Place your front foot sideways across the board, just behind the front bolts',
        'Crouch down and explode upward, snapping your back foot down hard',
        'As the tail hits the ground, slide your front foot up and forward',
        'Level out the board by pushing your front foot toward the nose',
        'Bend your knees to absorb the landing and stay balanced'
      ]
    },
    {
      id: 2,
      title: 'Kickflip Foot Positioning',
      description: 'Place your front foot at a 45-degree angle near the edge of the board for better flick control.',
      category: 'Flip Tricks',
      details: 'Proper foot positioning is crucial for consistent kickflips. The angle and placement of your front foot determines the flip.',
      bullets: [
        'Start with your front foot positioned like an ollie, but slightly more angled',
        'Place your front foot so your toes hang slightly off the edge',
        'Keep your back foot centered on the tail for a strong pop',
        'As you ollie up, flick your front foot off the corner of the nose',
        'The flick should be quick and sharp, like flicking something off your shoe',
        'Catch the board with both feet when the grip tape faces up'
      ]
    },
    {
      id: 3,
      title: 'Mental Game & Commitment',
      description: 'Visualize landing the trick before attempting. Fear often causes hesitation mid-trick.',
      category: 'Mindset',
      details: 'Skateboarding is as much mental as it is physical. Building confidence and commitment will help you progress faster.',
      bullets: [
        'Visualize yourself successfully landing the trick before attempting it',
        'Start with easier variations and build up confidence gradually',
        'Accept that falling is part of learning - wear protective gear when needed',
        'Focus on the feeling of landing rather than the fear of falling',
        'Break down complex tricks into smaller, manageable steps',
        'Celebrate small progress - every attempt teaches you something new'
      ]
    }
  ];

  const nextTip = () => {
    setCurrentTipIndex((prev) => (prev + 1) % dailyTrickTips.length);
  };

  const prevTip = () => {
    setCurrentTipIndex((prev) => (prev - 1 + dailyTrickTips.length) % dailyTrickTips.length);
  };

  const nextOnboardingStep = () => {
    if (onboardingStep < 4) {
      setOnboardingStep(onboardingStep + 1);
    } else {
      setIsOnboarding(false);
    }
  };

  const prevOnboardingStep = () => {
    if (onboardingStep > 1) {
      setOnboardingStep(onboardingStep - 1);
    }
  };

  const saveTip = (tipId: number) => {
    if (!savedTips.includes(tipId)) {
      setSavedTips(prev => [...prev, tipId]);
    }
  };

  const removeSavedTip = (tipId: number) => {
    setSavedTips(prev => prev.filter(id => id !== tipId));
  };

  const showDeleteConfirmation = (type: 'tip' | 'video', id: number, title: string) => {
    setDeleteConfirmation({
      isOpen: true,
      type,
      id,
      title
    });
  };

  const handleConfirmDelete = () => {
    if (deleteConfirmation.type === 'tip' && deleteConfirmation.id) {
      removeSavedTip(deleteConfirmation.id);
    } else if (deleteConfirmation.type === 'video' && deleteConfirmation.id) {
      // Handle video deletion here
      console.log('Deleting video:', deleteConfirmation.id);
    }
    
    setDeleteConfirmation({
      isOpen: false,
      type: null,
      id: null,
      title: ''
    });
  };

  const handleCancelDelete = () => {
    setDeleteConfirmation({
      isOpen: false,
      type: null,
      id: null,
      title: ''
    });
  };

  const openUploadModal = () => {
    setUploadModalOpen(true);
    setUploadStep('search');
    setSelectedTrick('');
    setUploadNotes('');
    setSelectedVideoFile(null);
    setTrimStart(0);
    setTrimEnd(5);
  };

  const closeUploadModal = () => {
    setUploadModalOpen(false);
    setUploadStep('search');
    setSelectedTrick('');
    setUploadNotes('');
    setSelectedVideoFile(null);
    setShowTrickSuggestions(false);
  };

  const handleTrickSearch = (value: string) => {
    setSelectedTrick(value);
    setShowTrickSuggestions(value.length > 0);
  };

  const selectTrickSuggestion = (trick: string) => {
    setSelectedTrick(trick);
    setShowTrickSuggestions(false);
  };

  const getFilteredTricks = () => {
    if (!selectedTrick) return [];
    return trickSuggestions
      .filter(trick => trick.toLowerCase().includes(selectedTrick.toLowerCase()))
      .slice(0, 5);
  };

  const handleVideoSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedVideoFile(file);
      
      // Create video element to check duration
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        setVideoDuration(video.duration);
        if (video.duration <= 10) {
          // Video is under 10 seconds, proceed to upload
          handleVideoUpload();
        } else {
          // Video is over 10 seconds, go to trim step
          setUploadStep('trim');
          setTrimEnd(Math.min(5, video.duration));
        }
      };
      video.src = URL.createObjectURL(file);
    }
  };

  const handleVideoUpload = () => {
    // Simulate upload process
    console.log('Uploading video:', {
      trick: selectedTrick,
      notes: uploadNotes,
      video: selectedVideoFile,
      trimStart,
      trimEnd: uploadStep === 'trim' ? trimEnd : videoDuration
    });
    
    closeUploadModal();
    // Would redirect to new attempt page here
  };

  const isTipSaved = (tipId: number) => {
    return savedTips.includes(tipId);
  };

  const openNotificationsModal = () => {
    setNotificationsModalOpen(true);
  };

  const closeNotificationsModal = () => {
    setNotificationsModalOpen(false);
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'video_uploaded':
        return Upload;
      case 'push_notification':
        return Bell;
      case 'tip_saved':
        return Bookmark;
      case 'coach_message':
        return MessageCircle;
      default:
        return Bell;
    }
  };

  const getActivityIconColor = (type: string) => {
    switch (type) {
      case 'video_uploaded':
        return 'text-blue-600 bg-blue-50';
      case 'push_notification':
        return 'text-orange-600 bg-orange-50';
      case 'tip_saved':
        return 'text-green-600 bg-green-50';
      case 'coach_message':
        return 'text-purple-600 bg-purple-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const generateYearOptions = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let year = currentYear; year >= 1960; year--) {
      years.push(year.toString());
    }
    return years;
  };

  const generateDayOptions = () => {
    const days = [];
    for (let day = 1; day <= 31; day++) {
      days.push(day.toString());
    }
    return days;
  };

  const openEditProfile = () => {
    setEditProfileModalOpen(true);
  };

  const closeEditProfile = () => {
    setEditProfileModalOpen(false);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedProfileImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
        setImageUploadModalOpen(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const saveProfileImage = () => {
    // Here you would save the cropped image
    console.log('Saving profile image with scale:', cropScale, 'position:', cropPosition);
    setImageUploadModalOpen(false);
    setSelectedProfileImage(null);
    setImagePreview(null);
    setCropScale(1);
    setCropPosition({ x: 0, y: 0 });
  };

  const startAccountDeletion = () => {
    setDeleteAccountStep('initial');
  };

  const confirmAccountDeletion = () => {
    setDeleteAccountStep('confirm');
  };

  const cancelAccountDeletion = () => {
    setDeleteAccountStep(null);
  };

  const deleteAccount = () => {
    // Handle account deletion
    console.log('Account deleted');
    setDeleteAccountStep(null);
    setIsAuthenticated(false);
    setAuthView('signin');
  };

  const handleSignIn = () => {
    setIsAuthenticated(true);
  };

  const handleSignUp = () => {
    setIsAuthenticated(true);
  };

  const handleSignOut = () => {
    setIsAuthenticated(false);
    setAuthView('signin');
  };

  const openSubscriptionModal = () => {
    setSubscriptionModalOpen(true);
  };

  const closeSubscriptionModal = () => {
    setSubscriptionModalOpen(false);
    setCancelSubscriptionStep(null);
  };

  const startSubscriptionCancellation = () => {
    setCancelSubscriptionStep('initial');
  };

  const confirmSubscriptionCancellation = () => {
    setCancelSubscriptionStep('confirm');
  };

  const cancelSubscriptionCancellation = () => {
    setCancelSubscriptionStep(null);
  };

  const cancelSubscription = () => {
    // Handle subscription cancellation
    console.log('Subscription cancelled');
    setCancelSubscriptionStep(null);
    setSubscriptionModalOpen(false);
    // Here you would update the user plan to 'free'
  };

  const handlePermissionToggle = (type: 'pushNotifications' | 'camera' | 'microphone') => {
    const isCurrentlyEnabled = permissions[type];
    
    if (isCurrentlyEnabled) {
      // If currently enabled, show confirmation to disable
      setPermissionConfirmModal({
        isOpen: true,
        type,
        action: 'disable'
      });
    } else {
      // If currently disabled, open OS settings
      openOSSettings(type);
    }
  };

  const confirmDisablePermission = () => {
    if (permissionConfirmModal.type) {
      setPermissions(prev => ({
        ...prev,
        [permissionConfirmModal.type!]: false
      }));
    }
    setPermissionConfirmModal({
      isOpen: false,
      type: null,
      action: null
    });
  };

  const cancelPermissionChange = () => {
    setPermissionConfirmModal({
      isOpen: false,
      type: null,
      action: null
    });
  };

  const openOSSettings = (type: 'pushNotifications' | 'camera' | 'microphone') => {
    // This would typically open the OS settings
    // For demo purposes, we'll simulate it and then re-enable the permission
    console.log(`Opening OS settings for ${type}`);
    
    // Simulate user enabling permission in OS settings
    setTimeout(() => {
      setPermissions(prev => ({
        ...prev,
        [type]: true
      }));
    }, 1000);
  };

  const getPermissionLabel = (type: 'pushNotifications' | 'camera' | 'microphone') => {
    return permissions[type] ? 'Enabled' : 'Disabled';
  };

  const getPermissionButtonVariant = (type: 'pushNotifications' | 'camera' | 'microphone') => {
    return permissions[type] ? 'outline' : 'outline';
  };

  const getPermissionButtonStyle = (type: 'pushNotifications' | 'camera' | 'microphone') => {
    return permissions[type] 
      ? 'border-green-300 text-green-700 hover:bg-green-50' 
      : 'border-red-300 text-red-700 hover:bg-red-50';
  };

  const handleVideosSearch = (value: string) => {
    setVideosSearchQuery(value);
    setShowVideosSearchSuggestions(value.length > 0);
  };

  const selectVideosSearchSuggestion = (trick: string) => {
    setVideosSearchQuery(trick);
    setShowVideosSearchSuggestions(false);
  };

  const getFilteredVideosSearchTricks = () => {
    if (!videosSearchQuery) return [];
    return trickSuggestions
      .filter(trick => trick.toLowerCase().includes(videosSearchQuery.toLowerCase()))
      .slice(0, 5);
  };

  const monthOptions = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const StatusIcon = ({ status }: { status: string }) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'processing':
        return <Clock className="w-4 h-4 text-orange-500" />;
      default:
        return <Play className="w-4 h-4 text-gray-400" />;
    }
  };

  const StatusBadge = ({ status }: { status: string }) => {
    const colors = {
      completed: 'bg-green-100 text-green-700 border-green-200',
      processing: 'bg-orange-100 text-orange-700 border-orange-200',
      pending: 'bg-gray-100 text-gray-700 border-gray-200'
    };
    
    const badge = (
      <Badge variant="outline" className={colors[status as keyof typeof colors] || colors.pending}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
    
    if (status === 'processing') {
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="inline-flex cursor-help">
                {badge}
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>We're processing your video. Taking too long? Tap View Details then the refresh button</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }
    
    return badge;
  };



  // Render sign in/sign up if user is not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Header */}
        <header className="px-4 py-6">
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gray-900 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-gray-900 font-semibold">SkateCoach</h1>
            </div>
          </div>
        </header>

        {/* Auth Content */}
        <main className="flex-1 px-4 py-6">
          <div className="w-full max-w-sm mx-auto space-y-8">
            {authView === 'signin' ? (
              <>
                {/* Sign In */}
                <div className="text-center space-y-4">
                  <h2 className="text-gray-900 text-2xl">Welcome back</h2>
                  <p className="text-gray-600">Sign in to continue your skating journey</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="signin-email" className="text-gray-900">Email</Label>
                    <Input
                      id="signin-email"
                      type="email"
                      placeholder="alex@example.com"
                      className="mt-2 bg-white border-gray-300"
                    />
                  </div>
                  <div>
                    <Label htmlFor="signin-password" className="text-gray-900">Password</Label>
                    <Input
                      id="signin-password"
                      type="password"
                      placeholder="••••••••"
                      className="mt-2 bg-white border-gray-300"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Button 
                    onClick={handleSignIn}
                    className="w-full h-12 bg-gray-900 hover:bg-gray-800 text-white"
                  >
                    Sign In
                  </Button>
                  <Button 
                    onClick={() => setAuthView('signup')}
                    variant="ghost"
                    className="w-full h-12 text-gray-600 hover:text-gray-700"
                  >
                    Don't have an account? Sign up
                  </Button>
                </div>
              </>
            ) : (
              <>
                {/* Sign Up */}
                <div className="text-center space-y-4">
                  <h2 className="text-gray-900 text-2xl">Create Account</h2>
                  <p className="text-gray-600">Start your skateboarding journey with personalized coaching</p>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="signup-firstName" className="text-gray-900">First name</Label>
                      <Input
                        id="signup-firstName"
                        placeholder="Alex"
                        className="mt-2 bg-white border-gray-300"
                      />
                    </div>
                    <div>
                      <Label htmlFor="signup-lastName" className="text-gray-900">Last name</Label>
                      <Input
                        id="signup-lastName"
                        placeholder="Rodriguez"
                        className="mt-2 bg-white border-gray-300"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="signup-email" className="text-gray-900">Email</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="alex@example.com"
                      className="mt-2 bg-white border-gray-300"
                    />
                  </div>
                  <div>
                    <Label htmlFor="signup-password" className="text-gray-900">Password</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      placeholder="••••••••"
                      className="mt-2 bg-white border-gray-300"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Button 
                    onClick={() => {
                      handleSignUp();
                      setIsOnboarding(true);
                    }}
                    className="w-full h-12 bg-gray-900 hover:bg-gray-800 text-white"
                  >
                    Create Account
                  </Button>
                  <Button 
                    onClick={() => setAuthView('signin')}
                    variant="ghost"
                    className="w-full h-12 text-gray-600 hover:text-gray-700"
                  >
                    Already have an account? Sign in
                  </Button>
                </div>

                <p className="text-xs text-gray-500 text-center">
                  By signing up, you agree to our Terms of Service and Privacy Policy
                </p>
              </>
            )}
          </div>
        </main>
      </div>
    );
  }

  // Render onboarding if user is in onboarding flow
  if (isOnboarding) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Header - Same as main app */}
        <header className="sticky top-0 z-50 bg-white border-b border-gray-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gray-900 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-gray-900 font-semibold">SkateCoach</h1>
            </div>
            <div className="flex items-center space-x-4">
              {onboardingStep > 1 && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={prevOnboardingStep}
                  className="p-2"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              )}
              <div className="w-24">
                <Progress value={(onboardingStep / 4) * 100} className="h-2" />
              </div>
            </div>
          </div>
        </header>

        {/* Onboarding Content */}
        <main className="flex-1 px-4 py-6">
          <div className="w-full max-w-sm mx-auto space-y-6">
            {onboardingStep === 1 && (
              <>
                {/* Welcome Screen */}
                <div className="text-center space-y-8">
                  <div className="aspect-square w-full max-w-xs mx-auto rounded-2xl overflow-hidden bg-gradient-to-br from-gray-100 via-gray-50 to-white border border-gray-200">
                    <ImageWithFallback 
                      src="https://images.unsplash.com/photo-1605450333415-d46b09609722?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxza2F0ZWJvYXJkJTIwbGluZSUyMGRyYXdpbmclMjB2ZWN0b3J8ZW58MXx8fHwxNzU3ODE1NTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
                      alt="Skateboard line drawing illustration" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <h1 className="text-gray-900 text-2xl">Welcome to SkateCoach!</h1>
                    <p className="text-gray-600 leading-relaxed">
                      From ollies to switch hardflips, you'll learn how to balance, position your feet, pop, flick and land tricks.
                    </p>
                  </div>
                </div>
              </>
            )}

            {onboardingStep === 2 && (
              <>
                {/* Skater Details Form */}
                <div className="space-y-8">
                  <div className="text-center space-y-3">
                    <h2 className="text-gray-900 text-xl">Tell us about yourself.</h2>
                    <p className="text-gray-600">It lets us know how we should coach you.</p>
                  </div>

                  <div className="space-y-8">
                    {/* Name Fields */}
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label htmlFor="firstName" className="text-gray-900">First name</Label>
                          <Input
                            id="firstName"
                            value={skaterDetails.firstName}
                            onChange={(e) => setSkaterDetails({...skaterDetails, firstName: e.target.value})}
                            className="mt-2 bg-white border-gray-300"
                          />
                        </div>
                        <div>
                          <Label htmlFor="lastName" className="text-gray-900">Last name</Label>
                          <Input
                            id="lastName"
                            value={skaterDetails.lastName}
                            onChange={(e) => setSkaterDetails({...skaterDetails, lastName: e.target.value})}
                            className="mt-2 bg-white border-gray-300"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Started Skating Year */}
                    <div className="space-y-3">
                      <Label className="text-gray-900">Started Skating</Label>
                      <Select value={skaterDetails.startedSkating} onValueChange={(value) => setSkaterDetails({...skaterDetails, startedSkating: value})}>
                        <SelectTrigger className="bg-white border-gray-300">
                          <SelectValue placeholder="Select year" />
                        </SelectTrigger>
                        <SelectContent className="max-h-48">
                          {generateYearOptions().map((year) => (
                            <SelectItem key={year} value={year}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Stance */}
                    <div className="space-y-3">
                      <Label className="text-gray-900">Stance</Label>
                      <div className="flex gap-3">
                        <Button
                          variant={skaterDetails.stance === 'regular' ? 'default' : 'outline'}
                          onClick={() => setSkaterDetails({...skaterDetails, stance: 'regular'})}
                          className={`flex-1 h-12 ${
                            skaterDetails.stance === 'regular' 
                              ? 'bg-gray-900 hover:bg-gray-800 text-white' 
                              : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          Regular
                        </Button>
                        <Button
                          variant={skaterDetails.stance === 'goofy' ? 'default' : 'outline'}
                          onClick={() => setSkaterDetails({...skaterDetails, stance: 'goofy'})}
                          className={`flex-1 h-12 ${
                            skaterDetails.stance === 'goofy' 
                              ? 'bg-gray-900 hover:bg-gray-800 text-white' 
                              : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          Goofy
                        </Button>
                      </div>
                    </div>

                    {/* Gender */}
                    <div className="space-y-3">
                      <Label className="text-gray-900">Gender</Label>
                      <div className="flex gap-3">
                        <Button
                          variant={skaterDetails.gender === 'male' ? 'default' : 'outline'}
                          onClick={() => setSkaterDetails({...skaterDetails, gender: 'male'})}
                          className={`flex-1 h-12 ${
                            skaterDetails.gender === 'male' 
                              ? 'bg-gray-900 hover:bg-gray-800 text-white' 
                              : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          Male
                        </Button>
                        <Button
                          variant={skaterDetails.gender === 'female' ? 'default' : 'outline'}
                          onClick={() => setSkaterDetails({...skaterDetails, gender: 'female'})}
                          className={`flex-1 h-12 ${
                            skaterDetails.gender === 'female' 
                              ? 'bg-gray-900 hover:bg-gray-800 text-white' 
                              : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                          }`}
                        >
                          Female
                        </Button>
                      </div>
                    </div>

                    {/* Birthday */}
                    <div className="space-y-3">
                      <Label className="text-gray-900">Birthday</Label>
                      <div className="grid grid-cols-3 gap-2">
                        <Select value={skaterDetails.birthMonth} onValueChange={(value) => setSkaterDetails({...skaterDetails, birthMonth: value})}>
                          <SelectTrigger className="bg-white border-gray-300">
                            <SelectValue placeholder="Month" />
                          </SelectTrigger>
                          <SelectContent>
                            {monthOptions.map((month, index) => (
                              <SelectItem key={month} value={(index + 1).toString()}>{month}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={skaterDetails.birthDay} onValueChange={(value) => setSkaterDetails({...skaterDetails, birthDay: value})}>
                          <SelectTrigger className="bg-white border-gray-300">
                            <SelectValue placeholder="Day" />
                          </SelectTrigger>
                          <SelectContent className="max-h-48">
                            {generateDayOptions().map((day) => (
                              <SelectItem key={day} value={day}>{day}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={skaterDetails.birthYear} onValueChange={(value) => setSkaterDetails({...skaterDetails, birthYear: value})}>
                          <SelectTrigger className="bg-white border-gray-300">
                            <SelectValue placeholder="Year" />
                          </SelectTrigger>
                          <SelectContent className="max-h-48">
                            {generateYearOptions().map((year) => (
                              <SelectItem key={year} value={year}>{year}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Learning Goals */}
                    <div className="space-y-3">
                      <Label htmlFor="learningGoals" className="text-gray-900">Anything you want to learn?</Label>
                      <Textarea
                        id="learningGoals"
                        placeholder="Tell us what tricks or skills you'd like to work on..."
                        value={skaterDetails.learningGoals}
                        onChange={(e) => setSkaterDetails({...skaterDetails, learningGoals: e.target.value})}
                        className="bg-white border-gray-300 min-h-24"
                      />
                    </div>
                  </div>
                </div>
              </>
            )}

            {onboardingStep === 3 && (
              <>
                {/* Upload Video Tutorial */}
                <div className="text-center space-y-8">
                  <div className="aspect-square w-full max-w-xs mx-auto rounded-2xl overflow-hidden bg-gradient-to-br from-gray-100 via-gray-50 to-white border border-gray-200">
                    <ImageWithFallback 
                      src="https://images.unsplash.com/photo-1722031489919-100378463cfc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaG9uZSUyMGNhbWVyYSUyMHJlY29yZGluZyUyMGlsbHVzdHJhdGlvbnxlbnwxfHx8fDE3NTc4MTU1NDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
                      alt="Phone camera recording illustration" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <h2 className="text-gray-900 text-xl">Just upload your video</h2>
                    <p className="text-gray-600 leading-relaxed">
                      And a coach will drop in notes for landing your trick right on the bolts.
                    </p>
                  </div>
                </div>
              </>
            )}

            {onboardingStep === 4 && (
              <>
                {/* Subscription Upsell */}
                <div className="text-center space-y-8">
                  <div className="aspect-square w-full max-w-xs mx-auto rounded-2xl overflow-hidden bg-gradient-to-br from-gray-100 via-gray-50 to-white border border-gray-200">
                    <ImageWithFallback 
                      src="https://images.unsplash.com/photo-1643290274113-1ff22efe2ce1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21tdW5pdHklMjBwZW9wbGUlMjBpbGx1c3RyYXRpb24lMjBmbGF0fGVufDF8fHx8MTc1NzgxNTU1Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
                      alt="Community people flat illustration" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h2 className="text-gray-900 text-xl">5 free uploads a month.</h2>
                      <h2 className="text-gray-900 text-xl">Or upgrade for unlimited.</h2>
                    </div>
                    <div className="space-y-3 text-gray-600">
                      <p>
                        Upload all the videos you want for just $5/month, plus chat with a coach to get tips on the fly.
                      </p>
                      <p>
                        For the price of a coffee, you can learn to skate so much faster.
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </main>

        {/* Sticky Bottom Button */}
        <div className="sticky bottom-0 z-50 bg-white border-t border-gray-200 px-4 py-4">
          {onboardingStep === 4 ? (
            <div className="space-y-3 max-w-sm mx-auto">
              <Button 
                onClick={nextOnboardingStep}
                className="w-full h-12 bg-gray-900 hover:bg-gray-800 text-white"
              >
                Go Pro
              </Button>
              <Button 
                onClick={nextOnboardingStep}
                variant="ghost"
                className="w-full h-12 text-gray-600"
              >
                Maybe Later
              </Button>
              <p className="text-xs text-gray-500 text-center mt-2">
                Your videos are stored in the cloud for up to 180 days.
              </p>
            </div>
          ) : (
            <div className="max-w-sm mx-auto">
              <Button 
                onClick={nextOnboardingStep}
                className="w-full h-12 bg-gray-900 hover:bg-gray-800 text-white"
              >
                Next
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gray-900 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-gray-900 font-semibold">SkateCoach</h1>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200 text-xs px-2 py-1">
              Pro
            </Badge>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={openNotificationsModal}
              className="p-2"
            >
              <Bell className="w-5 h-5 text-gray-600" />
            </Button>
            <button onClick={() => setActiveTab('profile')}>
              <Avatar className="w-8 h-8">
                <AvatarImage src="/placeholder-avatar.jpg" />
                <AvatarFallback className="bg-gray-200 text-gray-700">AX</AvatarFallback>
              </Avatar>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 space-y-6">
        {activeTab === 'home' && (
          <>
            {/* Welcome Section */}
            <div>
              <h2 className="text-gray-900 text-xl mb-1">Welcome back, Alex!</h2>
              <p className="text-gray-600">Ready to improve your skating today?</p>
            </div>



            {/* Action Button */}
            <div className="w-full">
              <Button 
                onClick={openUploadModal}
                className="h-14 w-full bg-gray-900 hover:bg-gray-800 text-white"
              >
                <div className="flex items-center space-x-2">
                  <Upload className="w-5 h-5" />
                  <span>Upload Video</span>
                </div>
              </Button>
            </div>

            {/* Daily Trick Tips Carousel */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-gray-900 font-medium">Daily Trick Tips</h3>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={prevTip}
                    className="p-2"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={nextTip}
                    className="p-2"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <Card className="p-4 bg-white border border-gray-200">
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="bg-gray-100 text-gray-700 border-gray-300 text-xs">
                      {dailyTrickTips[currentTipIndex].category}
                    </Badge>
                    <span className="text-xs text-gray-500">
                      {currentTipIndex + 1} of {dailyTrickTips.length}
                    </span>
                  </div>
                  <h4 className="font-medium text-gray-900 mb-2">
                    {dailyTrickTips[currentTipIndex].title}
                  </h4>
                  <p className="text-sm text-gray-600 mb-3">
                    {dailyTrickTips[currentTipIndex].description}
                  </p>
                  <div className="flex items-center space-x-2">
                    <Dialog open={tipModalOpen} onOpenChange={setTipModalOpen}>
                      <DialogTrigger asChild>
                        <button className="p-0 h-auto text-sm text-gray-600 hover:underline bg-transparent border-none cursor-pointer">
                          Learn More
                        </button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md w-[calc(100vw-2rem)] mx-auto my-4">
                        <DialogHeader>
                          <DialogTitle className="text-gray-900">
                            {dailyTrickTips[currentTipIndex].title}
                          </DialogTitle>
                          <DialogDescription className="text-gray-600">
                            {dailyTrickTips[currentTipIndex].description}
                          </DialogDescription>
                        </DialogHeader>
                        
                        <div className="space-y-4">
                          <Badge variant="outline" className="bg-gray-100 text-gray-700 border-gray-300 text-xs w-fit">
                            {dailyTrickTips[currentTipIndex].category}
                          </Badge>
                          
                          <p className="text-sm text-gray-600">
                            {dailyTrickTips[currentTipIndex].details}
                          </p>
                          
                          <div>
                            <h4 className="text-sm font-medium text-gray-900 mb-3">Step by Step:</h4>
                            <ul className="space-y-2">
                              {dailyTrickTips[currentTipIndex].bullets.map((bullet, index) => (
                                <li key={index} className="flex items-start space-x-2">
                                  <span className="w-5 h-5 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <span className="text-xs text-gray-600">{index + 1}</span>
                                  </span>
                                  <span className="text-sm text-gray-600">{bullet}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          
                          <div className="flex space-x-2 pt-4">
                            <Button 
                              onClick={() => {
                                const tipId = dailyTrickTips[currentTipIndex].id;
                                if (isTipSaved(tipId)) {
                                  removeSavedTip(tipId);
                                } else {
                                  saveTip(tipId);
                                }
                              }}
                              variant={isTipSaved(dailyTrickTips[currentTipIndex].id) ? "default" : "outline"}
                              className={`flex-1 ${
                                isTipSaved(dailyTrickTips[currentTipIndex].id)
                                  ? 'bg-gray-900 hover:bg-gray-800 text-white'
                                  : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                              }`}
                            >
                              <Heart className={`w-4 h-4 mr-2 ${
                                isTipSaved(dailyTrickTips[currentTipIndex].id) ? 'fill-current' : ''
                              }`} />
                              {isTipSaved(dailyTrickTips[currentTipIndex].id) ? 'Saved' : 'Save Tip'}
                            </Button>
                            <Button 
                              onClick={() => setTipModalOpen(false)}
                              variant="outline"
                              className="border-gray-300 text-gray-700 hover:bg-gray-50"
                            >
                              Done
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </Card>
            </div>

            {/* Recent Uploads */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-gray-900 font-medium">Recent Uploads</h3>
                <Button 
                  variant="link" 
                  onClick={() => setActiveTab('videos')}
                  className="p-0 h-auto text-sm text-gray-600"
                >
                  View All
                </Button>
              </div>
              
              <div className="space-y-3">
                {recentUploads.map((upload) => (
                  <Card key={upload.id} className="p-4 bg-white border border-gray-200">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                          <PlaySquare className="w-5 h-5 text-gray-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{upload.trick}</h4>
                          <p className="text-xs text-gray-500">{upload.timestamp}</p>
                        </div>
                      </div>
                      <StatusBadge status={upload.status} />
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-3">{upload.feedback}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-500">Score:</span>
                        <span className="text-sm font-medium text-gray-900">
                          {upload.score ? `${upload.score}/10` : '-'}
                        </span>
                      </div>
                      <Button variant="link" className="p-0 h-auto text-xs text-gray-600">
                        View Details
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === 'coach' && (
          <div className="flex flex-col h-full">
            <div className="flex-1 space-y-6">
              {/* Coach Header */}
              <div>
                <h2 className="text-gray-900 text-xl mb-1">Coach Chat</h2>
                <p className="text-gray-600">Get advice to help improve your skating.</p>
              </div>

              {/* Coach Introduction */}
              <Card className="p-4 bg-white border border-gray-200">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Megaphone className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900 mb-1">Alex's SkateCoach</h3>
                    <p className="text-sm text-gray-600">Ask me anything about skateboarding techniques, tricks, drills, or get more more feedback on your uploaded videos.</p>
                  </div>
                </div>
              </Card>

              {/* Quick Questions */}
              <div>
                <h3 className="text-gray-900 font-medium mb-3">Quick Questions</h3>
                <div className="grid gap-2">
                  {[
                    "How can I ollie higher?",
                    "Tips for landing kickflips consistently?",
                    "What should I focus on as a beginner?",
                    "Help me with my balance and stance"
                  ].map((question, index) => (
                    <Button 
                      key={index}
                      variant="outline" 
                      className="h-auto p-3 text-left justify-start border-gray-300 text-gray-700 hover:bg-gray-50"
                    >
                      <span className="text-sm">{question}</span>
                    </Button>
                  ))}
                </div>
              </div>

              {/* Recent Conversation */}
              <div className={coachMessages.length > 0 ? 'pb-20' : ''}>
                <h3 className="text-gray-900 font-medium mb-4">Recent Conversation</h3>
                <div className="space-y-4">
                  {coachMessages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[80%] ${
                        msg.type === 'user' 
                          ? 'bg-gray-900 text-white' 
                          : 'bg-white border border-gray-200'
                      } rounded-lg p-3`}>
                        <p className="text-sm">{msg.message}</p>
                        <p className={`text-xs mt-1 ${
                          msg.type === 'user' ? 'text-gray-300' : 'text-gray-500'
                        }`}>
                          {msg.timestamp}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Chat Input - Sticky when there are conversations */}
            {coachMessages.length > 0 && (
              <div className="fixed bottom-16 left-0 right-0 bg-gray-50 px-4 py-4 border-t border-gray-200 z-40">
                <div className="flex space-x-2">
                  <div className="flex-1 relative">
                    <input 
                      type="text" 
                      placeholder="Ask Coach something..."
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent"
                    />
                  </div>
                  <Button className="bg-gray-900 hover:bg-gray-800 px-4 py-3">
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'videos' && !selectedVideo && (
          <>
            {/* Videos Header */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-gray-900 text-xl mb-1">My Uploaded Tricks</h2>
                <p className="text-gray-600">Review your uploaded videos and coaching feedback</p>
              </div>
              <Button 
                onClick={openUploadModal}
                className="bg-gray-900 hover:bg-gray-800 text-white"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload New
              </Button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input 
                value={videosSearchQuery}
                onChange={(e) => handleVideosSearch(e.target.value)}
                placeholder="Search your tricks..." 
                className="pl-10 bg-white border-gray-300"
                onFocus={() => setShowVideosSearchSuggestions(videosSearchQuery.length > 0)}
              />
              
              {/* Search Suggestions Dropdown */}
              {showVideosSearchSuggestions && getFilteredVideosSearchTricks().length > 0 && (
                <div className="absolute top-full left-0 right-0 z-50 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                  {getFilteredVideosSearchTricks().map((trick, index) => (
                    <button
                      key={index}
                      onClick={() => selectVideosSearchSuggestion(trick)}
                      className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg"
                    >
                      {trick}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Videos by Month */}
            <div className="space-y-6">
              {Object.entries(videosByMonth).map(([month, videos]) => (
                <div key={month}>
                  {/* Month Header */}
                  <h3 className="text-gray-900 font-medium mb-3">{month}</h3>
                  
                  {/* Videos for this month */}
                  <div className="space-y-3">
                    {videos.map((video) => (
                      <Card key={video.id} className="p-4 bg-white border border-gray-200">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                              <PlaySquare className="w-5 h-5 text-gray-600" />
                            </div>
                            <div>
                              <h4 className="font-medium text-gray-900">{video.trick}</h4>
                              <p className="text-xs text-gray-500">{video.timestamp}</p>
                            </div>
                          </div>
                          <StatusBadge status={video.status} />
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-3">{video.feedback}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs text-gray-500">Score:</span>
                            <span className="text-sm font-medium text-gray-900">
                              {video.score ? `${video.score}/10` : '-'}
                            </span>
                          </div>
                          <Button 
                            variant="link" 
                            className="p-0 h-auto text-xs text-gray-600"
                            onClick={() => setSelectedVideo(video.id)}
                          >
                            View Details
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Storage Info */}
            <Card className="p-4 bg-gray-50 border border-gray-200">
              <p className="text-sm text-gray-600 text-center">
                Your videos are stored in the cloud for up to 180 days.
              </p>
            </Card>
          </>
        )}

        {activeTab === 'videos' && selectedVideo && (
          <>
            {/* Video Detail Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setSelectedVideo(null)}
                  className="p-2"
                >
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <div>
                  <h2 className="text-gray-900 text-xl">Kickflip Attempt</h2>
                  <p className="text-gray-600 text-sm">Sep 12 • 2024, 4:54 PM</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="ghost" size="sm" className="p-2">
                  <RotateCcw className="w-4 h-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => showDeleteConfirmation('video', selectedVideo, 'Kickflip Attempt')}
                  className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Video Player */}
            <Card className="p-4 bg-white border border-gray-200">
              <div className="aspect-video bg-gray-900 rounded-lg mb-4 flex items-center justify-center">
                <div className="text-center text-white">
                  <Play className="w-12 h-12 mx-auto mb-2 opacity-75" />
                  <p className="text-sm opacity-75">Video Player</p>
                  <p className="text-xs opacity-50">HTML5 video controls would be here</p>
                </div>
              </div>
            </Card>

            {/* Feedback Section */}
            <Card className="p-4 bg-white border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium text-gray-900">Coach Feedback</h3>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-500">Score:</span>
                  <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">
                    7.2/10
                  </Badge>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Great progress on your pop timing! Focus on keeping your shoulders aligned with the board throughout the trick. Your board rotation is clean, but committing more to the landing will help you stick it consistently.
              </p>
              
              {/* Improvement Areas */}
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-900 mb-3">Areas to Focus On</h4>
                <div className="flex flex-wrap gap-2">
                  {['shoulders', 'balance', 'confidence'].map((tagId) => {
                    const tag = improvementTags.find(t => t.id === tagId);
                    if (!tag) return null;
                    return (
                      <Button 
                        key={tagId}
                        variant="outline" 
                        size="sm" 
                        className="h-8 px-3 bg-orange-50 border-orange-200 text-orange-700 hover:bg-orange-100"
                      >
                        {tag.label}
                      </Button>
                    );
                  })}
                </div>
              </div>
            </Card>

            {/* Coach Chat for This Video */}
            <Card className="p-4 bg-white border border-gray-200">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                  <Megaphone className="w-4 h-4 text-gray-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">Kickflip Coach Chat</h3>
                  <p className="text-xs text-gray-500">Ask another question about this try.</p>
                </div>
              </div>

              {/* Improvement Tags */}
              <div className="mb-4">
                <p className="text-sm text-gray-600 mb-3">What would you like help with?</p>
                <div className="grid grid-cols-3 gap-2">
                  {improvementTags.map((tag) => (
                    <Button 
                      key={tag.id}
                      variant="outline" 
                      size="sm" 
                      className="h-8 px-3 text-xs border-gray-300 text-gray-700 hover:bg-gray-50"
                    >
                      {tag.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Chat Messages */}
              <div className="space-y-3 mb-4">
                {videoCoachMessages.map((msg) => (
                  <div key={msg.id} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] ${
                      msg.type === 'user' 
                        ? 'bg-gray-900 text-white' 
                        : 'bg-gray-50 border border-gray-200'
                    } rounded-lg p-3`}>
                      <p className="text-sm">{msg.message}</p>
                      <p className={`text-xs mt-1 ${
                        msg.type === 'user' ? 'text-gray-300' : 'text-gray-500'
                      }`}>
                        {msg.timestamp}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Chat Input */}
              <div className="flex space-x-2">
                <div className="flex-1">
                  <input 
                    type="text" 
                    placeholder="Ask the coach a question..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent text-sm"
                  />
                </div>
                <Button size="sm" className="bg-gray-900 hover:bg-gray-800 px-3">
                  Send
                </Button>
              </div>
            </Card>
          </>
        )}

        {activeTab === 'profile' && (
          <>
            {/* Profile Header */}
            <div>
              <h2 className="text-gray-900 text-xl mb-1">Profile</h2>
              <p className="text-gray-600">Manage your account and skating progress</p>
            </div>

            {/* Account Section */}
            <div>
              <h3 className="text-gray-900 font-medium mb-4">Account</h3>
              <Card className="p-4 bg-white border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-gray-900">Account Details</h4>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={openEditProfile}
                    className="p-2"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex items-center space-x-4 mb-4">
                  <Avatar className="w-16 h-16">
                    <AvatarImage src="/placeholder-avatar.jpg" />
                    <AvatarFallback className="bg-gray-200 text-gray-700 text-lg">AX</AvatarFallback>
                  </Avatar>
                  <div>
                    <h5 className="font-medium text-gray-900">Alex Rodriguez</h5>
                    <p className="text-sm text-gray-600">alex.rodriguez@email.com</p>
                    <p className="text-xs text-gray-500">Skating since 2018</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-lg font-medium text-gray-900">47</p>
                    <p className="text-xs text-gray-600">Videos Uploaded</p>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-lg font-medium text-gray-900">6.8</p>
                    <p className="text-xs text-gray-600">Avg Score</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Subscription Section */}
            <div>
              <h3 className="text-gray-900 font-medium mb-4">Subscription</h3>
              <Card className="p-4 bg-white border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-medium text-gray-900">SkateCoach Pro</h4>
                    <p className="text-sm text-gray-600">$5.00/month • Renews Oct 14, 2024</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
                      Active
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={openSubscriptionModal}
                      className="p-2"
                    >
                      <Settings className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                {/* Pro Features */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Unlimited video uploads</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Coach chat access</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Advanced trick analysis</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Daily trick tips</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Priority support</span>
                  </div>
                </div>

                {/* Monthly Usage */}
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Monthly Coach Reviewed Videos</span>
                    <span className="text-sm font-medium text-gray-900">Unlimited</span>
                  </div>
                  <p className="text-xs text-gray-500">47 videos uploaded this month</p>
                </div>
              </Card>
            </div>

            {/* Saved Tips Section */}
            <div>
              <h3 className="text-gray-900 font-medium mb-4">Saved Tips</h3>
              {savedTips.length === 0 ? (
                <Card className="p-6 bg-white border border-gray-200">
                  <div className="text-center">
                    <Bookmark className="w-8 h-8 text-gray-400 mx-auto mb-3" />
                    <h4 className="font-medium text-gray-900 mb-1">No saved tips yet</h4>
                    <p className="text-sm text-gray-600">
                      Save helpful tips from the Daily Trick Tips to access them anytime.
                    </p>
                  </div>
                </Card>
              ) : (
                <div className="space-y-3">
                  {savedTips.map((tipId) => {
                    const tip = dailyTrickTips.find(t => t.id === tipId);
                    if (!tip) return null;
                    
                    return (
                      <Card key={tipId} className="p-4 bg-white border border-gray-200">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <Badge variant="outline" className="bg-gray-100 text-gray-700 border-gray-300 text-xs">
                                {tip.category}
                              </Badge>
                            </div>
                            <h4 className="font-medium text-gray-900 mb-1">{tip.title}</h4>
                            <p className="text-sm text-gray-600">{tip.description}</p>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => showDeleteConfirmation('tip', tipId, tip.title)}
                            className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        
                        <div className="flex space-x-2 pt-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <button className="p-0 h-auto text-sm text-gray-600 hover:underline bg-transparent border-none cursor-pointer">
                                View Details
                              </button>
                            </DialogTrigger>
                            <DialogContent className="max-w-md w-[calc(100vw-2rem)] mx-auto my-4">
                              <DialogHeader>
                                <DialogTitle className="text-gray-900">{tip.title}</DialogTitle>
                                <DialogDescription className="text-gray-600">
                                  {tip.description}
                                </DialogDescription>
                              </DialogHeader>
                              
                              <div className="space-y-4">
                                <Badge variant="outline" className="bg-gray-100 text-gray-700 border-gray-300 text-xs w-fit">
                                  {tip.category}
                                </Badge>
                                
                                <p className="text-sm text-gray-600">{tip.details}</p>
                                
                                <div>
                                  <h4 className="text-sm font-medium text-gray-900 mb-3">Step by Step:</h4>
                                  <ul className="space-y-2">
                                    {tip.bullets.map((bullet, index) => (
                                      <li key={index} className="flex items-start space-x-2">
                                        <span className="w-5 h-5 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                          <span className="text-xs text-gray-600">{index + 1}</span>
                                        </span>
                                        <span className="text-sm text-gray-600">{bullet}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                                
                                <div className="flex justify-end pt-4">
                                  <DialogTrigger asChild>
                                    <Button 
                                      className="bg-gray-900 hover:bg-gray-800 text-white"
                                    >
                                      Done
                                    </Button>
                                  </DialogTrigger>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>



            {/* Preferences Section */}
            <div>
              <h3 className="text-gray-900 font-medium mb-4">Preferences</h3>
              <Card className="p-4 bg-white border border-gray-200">
                <h4 className="font-medium text-gray-900 mb-2">App Permissions</h4>
                <p className="text-sm text-gray-600 mb-6">
                  We keep your videos and information safe – and promise not to bother you.
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Smartphone className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h5 className="font-medium text-gray-900">Push Notifications</h5>
                        <Button 
                          variant={getPermissionButtonVariant('pushNotifications')}
                          size="sm"
                          onClick={() => handlePermissionToggle('pushNotifications')}
                          className={getPermissionButtonStyle('pushNotifications')}
                        >
                          {getPermissionLabel('pushNotifications')}
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600">
                        Stay in touch on video upload progress and alerts from Coach.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Camera className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h5 className="font-medium text-gray-900">Camera Access</h5>
                        <Button 
                          variant={getPermissionButtonVariant('camera')}
                          size="sm"
                          onClick={() => handlePermissionToggle('camera')}
                          className={getPermissionButtonStyle('camera')}
                        >
                          {getPermissionLabel('camera')}
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600">
                        So you can upload videos and stream your trick practice.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mic className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h5 className="font-medium text-gray-900">Microphone</h5>
                        <Button 
                          variant={getPermissionButtonVariant('microphone')}
                          size="sm"
                          onClick={() => handlePermissionToggle('microphone')}
                          className={getPermissionButtonStyle('microphone')}
                        >
                          {getPermissionLabel('microphone')}
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600">
                        When you stream video, we can hear your pop, flick, and stomp.
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            {/* Account Deletion */}
            <div className="pt-4 border-t border-gray-200">
              <Button 
                variant="ghost" 
                onClick={startAccountDeletion}
                className="w-full text-red-600 hover:text-red-700 hover:bg-red-50 text-sm"
              >
                Delete Account
              </Button>
            </div>

            {/* Sign Out */}
            <div className="pt-2">
              <Button 
                variant="ghost" 
                onClick={handleSignOut}
                className="w-full text-gray-600 hover:text-gray-700 hover:bg-gray-50"
              >
                Sign Out
              </Button>
            </div>
          </>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="sticky bottom-0 z-50 bg-white border-t border-gray-200 px-4 py-2">
        <div className="flex items-center justify-around">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'videos', icon: Video, label: 'Videos' },
            { id: 'coach', icon: MessageCircle, label: 'Coach' },
            { id: 'profile', icon: User, label: 'Profile' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center space-y-1 p-2 rounded-lg transition-colors ${
                activeTab === tab.id 
                  ? 'text-gray-900 bg-gray-100' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="text-xs">{tab.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {/* Notifications Modal */}
      <Dialog open={notificationsModalOpen} onOpenChange={closeNotificationsModal}>
        <DialogContent className="max-w-md w-[calc(100vw-2rem)] mx-auto my-4 h-[80vh] flex flex-col p-0">
          {/* Sticky Header */}
          <div className="sticky top-0 z-10 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <DialogHeader className="flex-1">
              <DialogTitle className="text-gray-900">
                {skaterDetails.firstName ? `${skaterDetails.firstName}'s Activity` : 'Your Activity'}
              </DialogTitle>
              <DialogDescription className="text-gray-600">
                Recent uploads, notifications, and saved tips
              </DialogDescription>
            </DialogHeader>
            <Button 
              onClick={closeNotificationsModal}
              className="bg-gray-900 hover:bg-gray-800 text-white ml-4"
            >
              Done
            </Button>
          </div>
          
          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="space-y-4">
              {activityData.map((activity) => {
                const IconComponent = getActivityIcon(activity.type);
                const iconColorClass = getActivityIconColor(activity.type);
                
                return (
                  <div key={activity.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${iconColorClass}`}>
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-gray-900 mb-1">{activity.title}</h4>
                      <p className="text-sm text-gray-600 mb-2 leading-relaxed">{activity.description}</p>
                      <p className="text-xs text-gray-500">{activity.timestamp}</p>
                    </div>
                  </div>
                );
              })}
              
              {/* End of Activity Message */}
              <div className="text-center py-6">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-6 h-6 text-gray-400" />
                </div>
                <p className="text-sm text-gray-500">You're all caught up!</p>
                <p className="text-xs text-gray-400 mt-1">That's all your recent activity</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Upload Video Modal */}
      <Dialog open={uploadModalOpen} onOpenChange={closeUploadModal}>
        <DialogContent className="max-w-md w-[calc(100vw-2rem)] mx-auto my-4">
          {uploadStep === 'search' && (
            <>
              <DialogHeader>
                <DialogTitle className="text-gray-900">Upload Video</DialogTitle>
                <DialogDescription className="text-gray-600">
                  Tell us what trick you're working on.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Trick Search */}
                <div className="space-y-3 relative">
                  <Label htmlFor="trick-search" className="text-gray-900">What trick are you practicing?</Label>
                  <div className="relative">
                    <Input
                      id="trick-search"
                      value={selectedTrick}
                      onChange={(e) => handleTrickSearch(e.target.value)}
                      placeholder="Start typing a trick name..."
                      className="bg-white border-gray-300"
                      onFocus={() => setShowTrickSuggestions(selectedTrick.length > 0)}
                    />
                    
                    {/* Trick Suggestions Dropdown */}
                    {showTrickSuggestions && getFilteredTricks().length > 0 && (
                      <div className="absolute top-full left-0 right-0 z-50 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                        {getFilteredTricks().map((trick, index) => (
                          <button
                            key={index}
                            onClick={() => selectTrickSuggestion(trick)}
                            className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg"
                          >
                            {trick}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Notes */}
                <div className="space-y-3">
                  <Label htmlFor="upload-notes" className="text-gray-900">Any notes you want to add?</Label>
                  <Textarea
                    id="upload-notes"
                    value={uploadNotes}
                    onChange={(e) => setUploadNotes(e.target.value)}
                    placeholder="I keep landing with one foot off the board..."
                    className="bg-white border-gray-300 min-h-20"
                  />
                </div>

                {/* Video Upload Info */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Video Requirements</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Maximum 10 seconds long</li>
                    <li>• Supported formats: MP4, MOV, AVI, WMV</li>
                    <li>• Works with iOS, Android, macOS, and Windows</li>
                  </ul>
                </div>

                {/* Video Upload Button */}
                <div className="space-y-3">
                  <input
                    type="file"
                    accept="video/*"
                    onChange={handleVideoSelect}
                    className="hidden"
                    id="video-upload"
                  />
                  <Label htmlFor="video-upload">
                    <div className="w-full h-12 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center cursor-pointer hover:border-gray-400 hover:bg-gray-50">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <Upload className="w-5 h-5" />
                        <span>Select Video File</span>
                      </div>
                    </div>
                  </Label>
                </div>
              </div>
            </>
          )}

          {uploadStep === 'trim' && (
            <>
              <DialogHeader>
                <DialogTitle className="text-gray-900">Trim Your Video</DialogTitle>
                <DialogDescription className="text-gray-600">
                  Your video is {videoDuration.toFixed(1)} seconds. Please trim it to 10 seconds or less.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Video Preview */}
                <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
                  <div className="text-center text-white">
                    <Play className="w-8 h-8 mx-auto mb-2 opacity-75" />
                    <p className="text-sm opacity-75">Video Preview</p>
                    <p className="text-xs opacity-50">{selectedVideoFile?.name}</p>
                  </div>
                </div>

                {/* Trim Controls */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Trim Selection</span>
                    <span className="text-sm font-medium text-gray-900">
                      {(trimEnd - trimStart).toFixed(1)}s selected
                    </span>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs text-gray-600">
                        <span>Start: {trimStart.toFixed(1)}s</span>
                        <span>End: {trimEnd.toFixed(1)}s</span>
                      </div>
                      <Slider
                        value={[trimStart, trimEnd]}
                        onValueChange={([start, end]) => {
                          setTrimStart(start);
                          setTrimEnd(end);
                        }}
                        max={videoDuration}
                        step={0.1}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  {(trimEnd - trimStart) > 10 && (
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <p className="text-sm text-orange-700">
                        Selection must be 10 seconds or less. Current: {(trimEnd - trimStart).toFixed(1)}s
                      </p>
                    </div>
                  )}
                </div>

                {/* Upload Button */}
                <Button
                  onClick={handleVideoUpload}
                  disabled={(trimEnd - trimStart) > 10}
                  className="w-full bg-gray-900 hover:bg-gray-800 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Upload Trimmed Video
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <Dialog open={deleteConfirmation.isOpen} onOpenChange={handleCancelDelete}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] mx-auto my-4">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Are you sure?</DialogTitle>
            <DialogDescription className="text-gray-600">
              {deleteConfirmation.type === 'tip' 
                ? `This will remove "${deleteConfirmation.title}" from your saved tips.`
                : `This will permanently delete "${deleteConfirmation.title}" and all its data.`
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex space-x-3 pt-4">
            <Button 
              onClick={handleCancelDelete}
              variant="outline"
              className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              No
            </Button>
            <Button 
              onClick={handleConfirmDelete}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white"
            >
              Yes
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Profile Modal */}
      <Dialog open={editProfileModalOpen} onOpenChange={closeEditProfile}>
        <DialogContent className="max-w-md w-[calc(100vw-2rem)] mx-auto my-4 h-[80vh] flex flex-col p-0">
          {/* Sticky Header */}
          <div className="sticky top-0 z-10 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <DialogHeader className="flex-1">
              <DialogTitle className="text-gray-900">Edit Profile</DialogTitle>
              <DialogDescription className="text-gray-600">
                Update your skating profile information
              </DialogDescription>
            </DialogHeader>
            <Button 
              onClick={closeEditProfile}
              className="bg-gray-900 hover:bg-gray-800 text-white ml-4"
            >
              Save
            </Button>
          </div>
          
          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Profile Picture */}
            <div className="space-y-4">
              <Label className="text-gray-900">Profile Picture</Label>
              <div className="flex items-center space-x-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src="/placeholder-avatar.jpg" />
                  <AvatarFallback className="bg-gray-200 text-gray-700 text-xl">AX</AvatarFallback>
                </Avatar>
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    id="profile-image-upload"
                  />
                  <Label htmlFor="profile-image-upload">
                    <Button variant="outline" asChild className="cursor-pointer">
                      <span>Change Photo</span>
                    </Button>
                  </Label>
                </div>
              </div>
            </div>

            {/* Name Fields */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="edit-firstName" className="text-gray-900">First name</Label>
                  <Input
                    id="edit-firstName"
                    value={skaterDetails.firstName}
                    onChange={(e) => setSkaterDetails({...skaterDetails, firstName: e.target.value})}
                    className="mt-2 bg-white border-gray-300"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-lastName" className="text-gray-900">Last name</Label>
                  <Input
                    id="edit-lastName"
                    value={skaterDetails.lastName}
                    onChange={(e) => setSkaterDetails({...skaterDetails, lastName: e.target.value})}
                    className="mt-2 bg-white border-gray-300"
                  />
                </div>
              </div>
            </div>



            {/* Stance */}
            <div className="space-y-3">
              <Label className="text-gray-900">Stance</Label>
              <div className="flex gap-3">
                <Button
                  variant={skaterDetails.stance === 'regular' ? 'default' : 'outline'}
                  onClick={() => setSkaterDetails({...skaterDetails, stance: 'regular'})}
                  className={`flex-1 h-12 ${
                    skaterDetails.stance === 'regular' 
                      ? 'bg-gray-900 hover:bg-gray-800 text-white' 
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Regular
                </Button>
                <Button
                  variant={skaterDetails.stance === 'goofy' ? 'default' : 'outline'}
                  onClick={() => setSkaterDetails({...skaterDetails, stance: 'goofy'})}
                  className={`flex-1 h-12 ${
                    skaterDetails.stance === 'goofy' 
                      ? 'bg-gray-900 hover:bg-gray-800 text-white' 
                      : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Goofy
                </Button>
              </div>
            </div>

            {/* Learning Goals */}
            <div className="space-y-3">
              <Label htmlFor="edit-learningGoals" className="text-gray-900">Learning Goals</Label>
              <Textarea
                id="edit-learningGoals"
                placeholder="Tell us what tricks or skills you'd like to work on..."
                value={skaterDetails.learningGoals}
                onChange={(e) => setSkaterDetails({...skaterDetails, learningGoals: e.target.value})}
                className="bg-white border-gray-300 min-h-24"
              />
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image Upload/Crop Modal */}
      <Dialog open={imageUploadModalOpen} onOpenChange={() => setImageUploadModalOpen(false)}>
        <DialogContent className="max-w-md w-[calc(100vw-2rem)] mx-auto my-4">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Crop Profile Photo</DialogTitle>
            <DialogDescription className="text-gray-600">
              Pan and zoom to fit your photo in the circle
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Image Preview with Crop Overlay */}
            <div className="relative">
              <div className="w-full h-64 bg-gray-100 rounded-lg overflow-hidden relative">
                {imagePreview && (
                  <img 
                    src={imagePreview}
                    alt="Profile preview"
                    className="w-full h-full object-cover"
                    style={{
                      transform: `scale(${cropScale}) translate(${cropPosition.x}px, ${cropPosition.y}px)`
                    }}
                  />
                )}
                {/* Circular crop overlay */}
                <div className="absolute inset-0 bg-black bg-opacity-50">
                  <div className="absolute top-1/2 left-1/2 w-32 h-32 rounded-full border-4 border-white transform -translate-x-1/2 -translate-y-1/2"
                       style={{
                         boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.5)'
                       }}>
                  </div>
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-gray-900">Zoom</Label>
                <Slider
                  value={[cropScale]}
                  onValueChange={([value]) => setCropScale(value)}
                  min={0.5}
                  max={3}
                  step={0.1}
                  className="w-full"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-gray-900">Position X</Label>
                  <Slider
                    value={[cropPosition.x]}
                    onValueChange={([value]) => setCropPosition({...cropPosition, x: value})}
                    min={-100}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-gray-900">Position Y</Label>
                  <Slider
                    value={[cropPosition.y]}
                    onValueChange={([value]) => setCropPosition({...cropPosition, y: value})}
                    min={-100}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3 pt-4">
              <Button 
                onClick={() => setImageUploadModalOpen(false)}
                variant="outline"
                className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </Button>
              <Button 
                onClick={saveProfileImage}
                className="flex-1 bg-gray-900 hover:bg-gray-800 text-white"
              >
                Save Photo
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Account Deletion Modals */}
      <Dialog open={deleteAccountStep === 'initial'} onOpenChange={cancelAccountDeletion}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] mx-auto my-4">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Delete Account?</DialogTitle>
            <DialogDescription className="text-gray-600">
              Are you sure you want to delete your SkateCoach account?
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex space-x-3 pt-4">
            <Button 
              onClick={cancelAccountDeletion}
              variant="outline"
              className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              No
            </Button>
            <Button 
              onClick={confirmAccountDeletion}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white"
            >
              Yes
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteAccountStep === 'confirm'} onOpenChange={cancelAccountDeletion}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] mx-auto my-4">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Confirm Account Deletion</DialogTitle>
            <DialogDescription className="text-gray-600">
              Confirm you want to delete your SkateCoach account.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              This action will permanently delete all your uploaded videos, coaching feedback, saved tips, activity history, and account information. This cannot be undone.
            </p>
          </div>
          
          <div className="flex space-x-3 pt-4">
            <Button 
              onClick={cancelAccountDeletion}
              variant="outline"
              className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button 
              onClick={deleteAccount}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white"
            >
              Confirm Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Subscription Management Modal */}
      <Dialog open={subscriptionModalOpen} onOpenChange={closeSubscriptionModal}>
        <DialogContent className="max-w-md w-[calc(100vw-2rem)] mx-auto my-4 h-[80vh] flex flex-col p-0">
          {/* Sticky Header */}
          <div className="sticky top-0 z-10 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <DialogHeader className="flex-1">
              <DialogTitle className="text-gray-900">Subscription Management</DialogTitle>
              <DialogDescription className="text-gray-600">
                Manage your SkateCoach Pro subscription
              </DialogDescription>
            </DialogHeader>
            <Button 
              onClick={closeSubscriptionModal}
              className="bg-gray-900 hover:bg-gray-800 text-white ml-4"
            >
              Done
            </Button>
          </div>
          
          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {/* Current Plan */}
            <div className="space-y-4">
              <h3 className="text-gray-900 font-medium">Current Plan</h3>
              <Card className="p-4 bg-white border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-medium text-gray-900">SkateCoach Pro</h4>
                    <p className="text-sm text-gray-600">$5.00/month • Renews Oct 14, 2024</p>
                  </div>
                  <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
                    Active
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Unlimited video uploads</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Coach chat access</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Advanced trick analysis</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Daily trick tips</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-gray-600">Priority support</span>
                  </div>
                </div>
              </Card>
            </div>

            {/* Usage Summary */}
            <div className="space-y-4">
              <h3 className="text-gray-900 font-medium">Your Activity</h3>
              <Card className="p-4 bg-white border border-gray-200">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                        <PlaySquare className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Videos Uploaded</h4>
                        <p className="text-sm text-gray-600">Total since joining</p>
                      </div>
                    </div>
                    <span className="text-lg font-medium text-gray-900">47</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Coach Chat Sessions</h4>
                        <p className="text-sm text-gray-600">Active conversations</p>
                      </div>
                    </div>
                    <span className="text-lg font-medium text-gray-900">12</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
                        <Bookmark className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Saved Tips</h4>
                        <p className="text-sm text-gray-600">Tips in your collection</p>
                      </div>
                    </div>
                    <span className="text-lg font-medium text-gray-900">{savedTips.length}</span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center">
                        <Bell className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Coaching Sessions</h4>
                        <p className="text-sm text-gray-600">Videos reviewed by coach</p>
                      </div>
                    </div>
                    <span className="text-lg font-medium text-gray-900">34</span>
                  </div>
                </div>
              </Card>
            </div>

            {/* This Month Usage */}
            <div className="space-y-4">
              <h3 className="text-gray-900 font-medium">This Month</h3>
              <Card className="p-4 bg-gray-50 border border-gray-200">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Videos uploaded</span>
                    <span className="text-sm font-medium text-gray-900">8 videos</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Coach interactions</span>
                    <span className="text-sm font-medium text-gray-900">15 messages</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Tips saved</span>
                    <span className="text-sm font-medium text-gray-900">3 tips</span>
                  </div>
                </div>
              </Card>
            </div>

            {/* Cancel Subscription */}
            <div className="pt-4 border-t border-gray-200">
              <Button 
                variant="ghost" 
                onClick={startSubscriptionCancellation}
                className="w-full text-gray-600 hover:text-gray-700 hover:bg-gray-50 text-sm"
              >
                Cancel Subscription
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Subscription Cancellation Modals */}
      <Dialog open={cancelSubscriptionStep === 'initial'} onOpenChange={cancelSubscriptionCancellation}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] mx-auto my-4">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Cancel Subscription?</DialogTitle>
            <DialogDescription className="text-gray-600">
              Are you sure you want to cancel your SkateCoach Pro subscription?
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              You'll still have access to Pro features until your next billing date (Oct 14, 2024). After that, you'll switch to the free plan with 5 video uploads per month.
            </p>
          </div>
          
          <div className="flex space-x-3 pt-4">
            <Button 
              onClick={cancelSubscriptionCancellation}
              variant="outline"
              className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              No
            </Button>
            <Button 
              onClick={confirmSubscriptionCancellation}
              className="flex-1 bg-orange-600 hover:bg-orange-700 text-white"
            >
              Yes
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={cancelSubscriptionStep === 'confirm'} onOpenChange={cancelSubscriptionCancellation}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] mx-auto my-4">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Confirm Subscription Cancellation</DialogTitle>
            <DialogDescription className="text-gray-600">
              Please confirm you want to cancel your subscription
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              When you cancel, you'll keep access to your uploaded videos for up to 180 days, but you'll lose access to:
            </p>
            <ul className="text-sm text-gray-600 space-y-1 ml-4">
              <li>• Coach chat conversations</li>
              <li>• Unlimited video uploads</li>
              <li>• Advanced trick analysis</li>
              <li>• Daily trick tips</li>
              <li>• Priority support</li>
            </ul>
            <p className="text-sm text-gray-600">
              You can always resubscribe later to regain full access to all features.
            </p>
          </div>
          
          <div className="flex space-x-3 pt-4">
            <Button 
              onClick={cancelSubscriptionCancellation}
              variant="outline"
              className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button 
              onClick={cancelSubscription}
              className="flex-1 bg-orange-600 hover:bg-orange-700 text-white"
            >
              Confirm Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Permission Confirmation Modal */}
      <Dialog open={permissionConfirmModal.isOpen} onOpenChange={cancelPermissionChange}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] mx-auto my-4">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Are you sure?</DialogTitle>
            <DialogDescription className="text-gray-600">
              {permissionConfirmModal.type === 'pushNotifications' && 
                'You won\'t receive notifications about video uploads, coaching feedback, or daily tips.'
              }
              {permissionConfirmModal.type === 'camera' && 
                'You won\'t be able to upload videos or stream your skating practice.'
              }
              {permissionConfirmModal.type === 'microphone' && 
                'Coach won\'t be able to analyze audio feedback from your tricks.'
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex space-x-3 pt-4">
            <Button 
              onClick={cancelPermissionChange}
              variant="outline"
              className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              No
            </Button>
            <Button 
              onClick={confirmDisablePermission}
              className="flex-1 bg-orange-600 hover:bg-orange-700 text-white"
            >
              Yes, Turn Off
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}